#!/bin/sh
cd /home/ctf/ && ./neon_alley 2>&1
