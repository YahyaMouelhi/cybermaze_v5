#!/bin/sh
cd /home/ctf/ && exec /home/ctf/byterush 2>&1
