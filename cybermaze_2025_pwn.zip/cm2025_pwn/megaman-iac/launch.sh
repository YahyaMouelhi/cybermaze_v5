#!/bin/sh
cd /home/ctf/ && ./megaman-iac
